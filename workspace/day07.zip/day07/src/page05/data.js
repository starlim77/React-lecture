export default [
    {
        id: "1",
        name: "행운의 황금당근 인형",
        description: "계묘년 에디션",
        photo: "https://t1.kakaocdn.net/friends/prod/product/20221205181946438_8809814929604_8809814929604_AW_00.jpg",
        price: 35000,
    },
    {
        id: "2",
        name: "마이크리스마스쿠키 트리 브릭피규어",
        description: "크리스마스 에디션",
        photo: "https://t1.kakaocdn.net/friends/prod/product/20221206101312327_8809814929208_AW_09.jpg",
        price: 49000,
    },
    {
        id: "3",
        name: "혀땳은앙꼬 하트뿅뿅필로우",
        description: "앙꼬 베게",
        photo: "https://t1.kakaocdn.net/friends/prod/product/20221208113600555_8809814929536_BW_00.jpg",
        price: 24000,
    },
    {
        id: "4",
        name: "죠르디 매직쇼 오르골",
        description: "크리스마스 오르골",
        photo: "https://t1.kakaocdn.net/friends/prod/product/20221114174345307_8809814928973_AW_00.jpg",
        price: 40000,
    },
];
