import React from "react";

const Main = () => {
    return (
        <div className="main">
            <h1>카카오 프렌즈샵</h1>
            <h2>방문해주셔서 감사합니다.</h2>
            <p>
                <img src="https://t1.kakaocdn.net/friends/prod/main_tab/feed/media/media_0_20221130162545.jpg"></img>
            </p>
        </div>
    );
};

export default Main;
