export default [
    { title: "HOME", path: "/" },
    { title: "ABOUT", path: "/about" },
    { title: "CEO", path: "/ceo" },
    { title: "SUB01", path: "/sub01" },
];
