import React from "react";

const Sub01 = () => {
    return (
        <div className="page">
            <h1>Sub01 page</h1>
        </div>
    );
};

export default Sub01;
