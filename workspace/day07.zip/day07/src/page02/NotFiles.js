import React from "react";

const NotFiles = () => {
    return (
        <div>
            <h1>NotFiles page</h1>
        </div>
    );
};

export default NotFiles;
