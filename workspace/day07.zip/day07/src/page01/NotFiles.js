import React from "react";

const NotFiles = () => {
    return (
        <div>
            <h1>NotFiles</h1>
        </div>
    );
};

export default NotFiles;
