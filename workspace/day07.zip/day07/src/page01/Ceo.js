import React from "react";

const Ceo = () => {
    return (
        <div>
            <h1>Ceo</h1>
        </div>
    );
};

export default Ceo;
